#!/bin/sh
python3 calcMetrics_WTM.py --data_name $1 --queryset $2 --num_topic $3 --num_runs $4 --frac $5
