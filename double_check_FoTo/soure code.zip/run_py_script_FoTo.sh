#!/bin/sh
python3 run_script_FoTo.py --data_name $1 --queryset $2 --num_topic $3 --num_runs $4
